# coding=utf-8
"""
@project: maxkb
@Author：虎
@file： base_question_node.py
@date：2024/6/4 14:30
@desc:
"""

import base64
import json
import re
import time
from functools import reduce
from imghdr import what
from typing import Dict, List

from common.exception.app_exception import AppApiException
from common.utils.rsa_util import rsa_long_decrypt
from common.utils.shared_resource_auth import filter_authorized_ids, get_runtime_user_id
from common.utils.tool_code import ToolExecutor
from django.db.models import QuerySet
from django.utils.translation import gettext as _
from knowledge.models import File
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from models_provider.models import Model
from models_provider.tools import get_model_credential, get_model_instance_by_model_workspace_id
from tools.models import Tool, ToolType

from application.flow.common import WorkflowMode
from application.flow.i_step_node import INode, NodeResult
from application.flow.step_node.ai_chat_step_node.i_chat_node import IChatNode
from application.flow.tools import Reasoning, get_tools, mcp_response_generator
from application.models import Application, ApplicationAccessToken, ApplicationApiKey
from application.retrieval.dialogue import dialogue_guidance, prepare_history, response_guidance


def _write_context(
    node_variable: Dict, workflow_variable: Dict, node: INode, workflow, answer: str, reasoning_content: str
):
    chat_model = node_variable.get("chat_model")
    message_tokens = chat_model.get_num_tokens_from_messages(node_variable.get("message_list"))
    answer_tokens = chat_model.get_num_tokens(answer)
    node.context["message_tokens"] = message_tokens
    node.context["answer_tokens"] = answer_tokens
    node.context["answer"] = answer
    node.context["question"] = node_variable["question"]
    node.context["run_time"] = time.time() - node.context["start_time"]
    node.context["reasoning_content"] = reasoning_content
    if workflow.is_result(node, NodeResult(node_variable, workflow_variable)):
        node.answer_text = answer


def write_context_stream(node_variable: Dict, workflow_variable: Dict, node: INode, workflow):
    """
    写入上下文数据 (流式)
    @param node_variable:      节点数据
    @param workflow_variable:  全局数据
    @param node:               节点
    @param workflow:           工作流管理器
    """
    response = node_variable.get("result")
    answer = ""
    reasoning_content = ""
    model_setting = node.context.get(
        "model_setting",
        {"reasoning_content_enable": False, "reasoning_content_end": "</think>", "reasoning_content_start": "<think>"},
    )
    reasoning = Reasoning(
        model_setting.get("reasoning_content_start", "<think>"), model_setting.get("reasoning_content_end", "</think>")
    )
    response_reasoning_content = False

    for chunk in response:
        if workflow.is_the_task_interrupted():
            break
        reasoning_chunk = reasoning.get_reasoning_content(chunk)
        content_chunk = reasoning_chunk.get("content")
        if "reasoning_content" in chunk.additional_kwargs:
            response_reasoning_content = True
            reasoning_content_chunk = chunk.additional_kwargs.get("reasoning_content", "")
        else:
            reasoning_content_chunk = reasoning_chunk.get("reasoning_content")
        answer += content_chunk
        if reasoning_content_chunk is None:
            reasoning_content_chunk = ""
        reasoning_content += reasoning_content_chunk
        yield {
            "content": content_chunk,
            "reasoning_content": reasoning_content_chunk
            if model_setting.get("reasoning_content_enable", False)
            else "",
        }

    reasoning_chunk = reasoning.get_end_reasoning_content()
    answer += reasoning_chunk.get("content")
    reasoning_content_chunk = ""
    if not response_reasoning_content:
        reasoning_content_chunk = reasoning_chunk.get("reasoning_content")
    yield {
        "content": reasoning_chunk.get("content"),
        "reasoning_content": reasoning_content_chunk if model_setting.get("reasoning_content_enable", False) else "",
    }
    _write_context(node_variable, workflow_variable, node, workflow, answer, reasoning_content)


def write_context(node_variable: Dict, workflow_variable: Dict, node: INode, workflow):
    """
    写入上下文数据
    @param node_variable:      节点数据
    @param workflow_variable:  全局数据
    @param node:               节点实例对象
    @param workflow:           工作流管理器
    """
    response = node_variable.get("result")
    model_setting = node.context.get(
        "model_setting",
        {"reasoning_content_enable": False, "reasoning_content_end": "</think>", "reasoning_content_start": "<think>"},
    )
    reasoning = Reasoning(model_setting.get("reasoning_content_start"), model_setting.get("reasoning_content_end"))
    reasoning_result = reasoning.get_reasoning_content(response)
    reasoning_result_end = reasoning.get_end_reasoning_content()
    content = reasoning_result.get("content") + reasoning_result_end.get("content")
    meta = {**response.response_metadata, **response.additional_kwargs}
    if "reasoning_content" in meta:
        reasoning_content = meta.get("reasoning_content", "") or ""
    else:
        reasoning_content = (reasoning_result.get("reasoning_content") or "") + (
            reasoning_result_end.get("reasoning_content") or ""
        )
    _write_context(node_variable, workflow_variable, node, workflow, content, reasoning_content)


CHAT_FILE_LIST_FIELDS = ("image_list", "document_list", "audio_list", "video_list", "other_list")


def get_default_model_params_setting(model_id):
    model = QuerySet(Model).filter(id=model_id).first()
    credential = get_model_credential(model.provider, model.model_type, model.model_name)
    model_params_setting = credential.get_model_params_setting_form(model.model_name).get_default_form_data()
    return model_params_setting


def get_node_message(chat_record, runtime_node_id):
    node_details = chat_record.get_node_details_runtime_node_id(runtime_node_id)
    if node_details is None:
        return []
    return [HumanMessage(node_details.get("question")), AIMessage(node_details.get("answer"))]


def get_workflow_message(chat_record):
    return [chat_record.get_human_message(), chat_record.get_ai_message()]


def get_message(chat_record, dialogue_type, runtime_node_id):
    return (
        get_node_message(chat_record, runtime_node_id) if dialogue_type == "NODE" else get_workflow_message(chat_record)
    )


class BaseChatNode(IChatNode):
    def save_context(self, details, workflow_manage):
        self.context["answer"] = details.get("answer")
        self.context["question"] = details.get("question")
        self.context["reasoning_content"] = details.get("reasoning_content")
        for field in ("raw_question", "dialogue_context", "dialogue_policy"):
            self.context[field] = details.get(field)
        self.context["exception_message"] = details.get("err_message")
        if self.node_params.get("is_result", False):
            self.answer_text = details.get("answer")

    def execute(
        self,
        model_id,
        system,
        prompt,
        dialogue_number,
        history_chat_record,
        stream,
        chat_id,
        chat_record_id,
        model_params_setting=None,
        model_id_type=None,
        model_id_reference=None,
        dialogue_type=None,
        model_setting=None,
        mcp_servers=None,
        mcp_tool_id=None,
        mcp_tool_ids=None,
        mcp_source=None,
        tool_ids=None,
        application_ids=None,
        skill_tool_ids=None,
        mcp_output_enable=True,
        **kwargs,
    ) -> NodeResult:
        if dialogue_type is None:
            dialogue_type = "WORKFLOW"

        if model_id_type == "reference" and model_id_reference:
            reference_data = self.workflow_manage.get_reference_field(
                model_id_reference[0],
                model_id_reference[1:],
            )

            if reference_data and isinstance(reference_data, dict):
                model_id = reference_data.get("model_id", model_id)
                model_params_setting = reference_data.get("model_params_setting")
        elif model_id_type == "default":
            default_setting = self.workflow_manage.get_default_model_setting("LLM")
            model_id = default_setting.get("model_id")
            model_params_setting = default_setting.get("model_params_setting", model_params_setting)
        if model_id is None or model_id == "":
            raise Exception(_("Model is not allowed to be empty"))

        if model_params_setting is None and model_id:
            model_params_setting = get_default_model_params_setting(model_id)

        if model_setting is None:
            model_setting = {
                "reasoning_content_enable": False,
                "reasoning_content_end": "</think>",
                "reasoning_content_start": "<think>",
            }
        self.context["model_setting"] = model_setting
        workspace_id = self.workflow_manage.get_body().get("workspace_id")
        chat_model = get_model_instance_by_model_workspace_id(model_id, workspace_id, **(model_params_setting or {}))
        policy_enabled = kwargs.get("dialogue_policy_enabled", False)
        raw_question = kwargs.get("question", "")
        context_reference = kwargs.get("dialogue_context_reference") or []
        dialogue_context = ""
        if policy_enabled and len(context_reference) == 2:
            value = self.workflow_manage.get_reference_field(context_reference[0], context_reference[1:])
            if isinstance(value, str):
                dialogue_context = value
        question = self.generate_prompt_question(prompt, chat_model)
        # Only treat explicitly referenced text actually present in this prompt as evidence.
        if not isinstance(question.content, str) or question.content.count(dialogue_context) != 1:
            dialogue_context = ""
        history_message, policy_trace = self.prepare_dialogue_history(
            history_chat_record, dialogue_number, dialogue_type, self.runtime_node_id,
            dialogue_context, raw_question, policy_enabled)
        self.context["raw_question"] = raw_question
        self.context["dialogue_context"] = dialogue_context
        self.context["dialogue_policy"] = policy_trace
        self.context["history_message"] = [
            {"content": message.content, "role": message.type}
            for message in (history_message if history_message is not None else [])
        ]
        self.context["question"] = question.content
        system = self.workflow_manage.generate_prompt(system)
        guidance = dialogue_guidance(raw_question, policy_enabled)
        # Tool and multimodal nodes must retain their original execution instructions.
        if (mcp_servers or mcp_tool_id or mcp_tool_ids or tool_ids or application_ids or skill_tool_ids
                or not isinstance(question.content, str) or not raw_question or raw_question not in question.content):
            guidance = ""
        if guidance:
            system = (system or "") + "\n" + guidance
        policy_trace["brief_response"] = bool(guidance and response_guidance(raw_question, policy_enabled))
        self.context["system"] = system
        message_list = self.generate_message_list(question, history_message)
        self.context["message_list"] = message_list
        body = self.workflow_manage.get_body()
        runtime_user_id = get_runtime_user_id(
            user_id=body.get("user_id"),
            chat_user_id=body.get("chat_user_id"),
            chat_user_type=body.get("chat_user_type"),
        )

        # 过滤tool_id
        all_tool_ids = list(
            set(
                (mcp_tool_ids or [])
                + (tool_ids or [])
                + (skill_tool_ids or [])
                + ([mcp_tool_id] if mcp_tool_id else [])
            )
        )
        authorized_set = set(filter_authorized_ids("tool", all_tool_ids, workspace_id, user_id=runtime_user_id))

        mcp_tool_ids = [i for i in (mcp_tool_ids or []) if i in authorized_set]
        tool_ids = [i for i in (tool_ids or []) if i in authorized_set]
        skill_tool_ids = [i for i in (skill_tool_ids or []) if i in authorized_set]
        mcp_tool_id = mcp_tool_id if (mcp_tool_id and mcp_tool_id in authorized_set) else None
        # 处理 MCP 请求
        mcp_result = self._handle_mcp_request(
            mcp_source,
            mcp_servers,
            mcp_tool_id,
            mcp_tool_ids,
            tool_ids,
            application_ids,
            skill_tool_ids,
            mcp_output_enable,
            chat_model,
            SystemMessage(system),
            message_list,
            history_message,
            question,
            chat_id,
            workspace_id,
            runtime_user_id,
        )
        if mcp_result:
            return mcp_result
        message_list = [SystemMessage(system)] + message_list
        if stream:
            r = chat_model.stream(message_list)
            return NodeResult(
                {"result": r, "chat_model": chat_model, "message_list": message_list, "question": question.content},
                {},
                _write_context=write_context_stream,
            )
        else:
            r = chat_model.invoke(message_list)
            return NodeResult(
                {
                    "result": r,
                    "chat_model": chat_model,
                    "message_list": message_list,
                    "history_message": [
                        {"content": message.content, "role": message.type}
                        for message in (history_message if history_message is not None else [])
                    ],
                    "question": question.content,
                },
                {},
                _write_context=write_context,
            )

    def _handle_mcp_request(
        self,
        mcp_source,
        mcp_servers,
        mcp_tool_id,
        mcp_tool_ids,
        tool_ids,
        application_ids,
        skill_tool_ids,
        mcp_output_enable,
        chat_model,
        system_prompt,
        message_list,
        history_message,
        question,
        chat_id,
        workspace_id,
        runtime_user_id=None,
    ):

        mcp_servers_config = {}

        # 迁移过来mcp_source是None
        if mcp_source is None:
            mcp_source = "custom"
        # 兼容老数据
        if not mcp_tool_ids:
            mcp_tool_ids = []
        if mcp_tool_id:
            mcp_tool_ids = list(set(mcp_tool_ids + [mcp_tool_id]))
        if mcp_source == "custom" and mcp_servers:
            mcp_servers_config = json.loads(mcp_servers)
            mcp_servers_config = self.handle_variables(mcp_servers_config)
        elif mcp_tool_ids:
            mcp_tools = QuerySet(Tool).filter(id__in=mcp_tool_ids).values()
            for mcp_tool in mcp_tools:
                if mcp_tool and mcp_tool["is_active"]:
                    mcp_servers_config = {**mcp_servers_config, **json.loads(mcp_tool["code"])}
                    mcp_servers_config = self.handle_variables(mcp_servers_config)
        # 校验代码是否包括禁止的关键字
        ToolExecutor().validate_mcp_transport(json.dumps(mcp_servers_config))

        tool_init_params = {}
        tools = get_tools(
            self.workflow_manage.get_source_type(),
            self.workflow_manage.get_source_id(),
            tool_ids,
            workspace_id,
            runtime_user_id,
        )
        if tool_ids and len(tool_ids) > 0:  # 如果有工具ID，则将其转换为MCP
            self.context["tool_ids"] = tool_ids
            custom_tools_map = {
                str(t.id): t for t in QuerySet(Tool).filter(id__in=tool_ids, tool_type=ToolType.CUSTOM, is_active=True)
            }
            for tool_id in tool_ids:
                tool = custom_tools_map.get(str(tool_id))
                if tool is None:
                    continue
                executor = ToolExecutor()
                init_params_default_value = {i["field"]: i.get("default_value") for i in tool.init_field_list}
                if tool.init_params is not None:
                    tool_init_params = init_params_default_value | json.loads(rsa_long_decrypt(tool.init_params))
                else:
                    tool_init_params = init_params_default_value

                tool_config = executor.get_tool_mcp_config(tool, tool_init_params)

                mcp_servers_config[str(tool.id)] = tool_config

        if application_ids and len(application_ids) > 0:
            self.context["application_ids"] = application_ids
            apps_map = {str(a.id): a for a in QuerySet(Application).filter(id__in=application_ids, is_publish=True)}
            app_keys_map = {
                str(ak.application_id): ak
                for ak in QuerySet(ApplicationApiKey).filter(application_id__in=application_ids, is_active=True)
            }
            app_access_tokens_map = {
                str(at.application_id): at
                for at in QuerySet(ApplicationAccessToken).filter(application_id__in=application_ids)
            }
            for application_id in application_ids:
                app = apps_map.get(str(application_id))
                if app is None:
                    continue
                app_key = app_keys_map.get(str(application_id))
                if app_key is not None:
                    api_key = app_key.secret_key
                    application_access_token = app_access_tokens_map.get(str(app_key.application_id))
                    if application_access_token is not None and application_access_token.authentication:
                        raise AppApiException(
                            500,
                            _("Agent 【{name}】 access token authentication is not supported for agent tool").format(
                                name=app.name
                            ),
                        )
                else:
                    raise AppApiException(
                        500, _("Agent Key is required for agent tool 【{name}】").format(name=app.name)
                    )
                executor = ToolExecutor()
                app_config = executor.get_app_mcp_config(api_key, self.get_chat_files(), self.get_form_data())
                mcp_servers_config[app.name] = app_config

        if skill_tool_ids and len(skill_tool_ids) > 0:
            self.context["skill_tool_ids"] = skill_tool_ids
            skill_file_items = []
            skill_tools_map = {str(t.id): t for t in QuerySet(Tool).filter(id__in=skill_tool_ids, is_active=True)}
            for tool_id in skill_tool_ids:
                tool = skill_tools_map.get(str(tool_id))
                if tool is None:
                    continue
                init_params_default_value = {i["field"]: i.get("default_value") for i in tool.init_field_list}
                if tool.init_params is not None:
                    params = init_params_default_value | json.loads(rsa_long_decrypt(tool.init_params))
                else:
                    params = init_params_default_value

                skill_file_items.append({"tool_id": str(tool.id), "file_id": tool.code, "params": params})
            mcp_servers_config["skills"] = skill_file_items

        if len(mcp_servers_config) > 0 or len(tools) > 0:
            # 安全获取 application
            application_id = None
            tool_id = None
            knowledge_id = None
            if [WorkflowMode.KNOWLEDGE, WorkflowMode.KNOWLEDGE_LOOP].__contains__(
                self.workflow_manage.flow.workflow_mode
            ):
                knowledge_id = self.workflow_params.get("knowledge_id")
            elif [WorkflowMode.APPLICATION, WorkflowMode.APPLICATION_LOOP].__contains__(
                self.workflow_manage.flow.workflow_mode
            ):
                application_id = self.workflow_manage.work_flow_post_handler.chat_info.application.id
            elif [WorkflowMode.TOOL, WorkflowMode.TOOL_LOOP].__contains__(self.workflow_manage.flow.workflow_mode):
                tool_id = self.workflow_params.get("tool_id")

            source_id = application_id or knowledge_id or tool_id
            source_type = "APPLICATION" if application_id else "KNOWLEDGE" if knowledge_id else "TOOL"
            r = mcp_response_generator(
                chat_model,
                system_prompt,
                message_list,
                mcp_servers_config,
                mcp_output_enable,
                tool_init_params,
                source_id,
                source_type,
                chat_id,
                tools,
            )
            return NodeResult(
                {
                    "result": r,
                    "chat_model": chat_model,
                    "message_list": message_list,
                    "history_message": [
                        {"content": message.content, "role": message.type}
                        for message in (history_message if history_message is not None else [])
                    ],
                    "question": question.content,
                },
                {},
                _write_context=write_context_stream,
            )

        return None

    def get_chat_files(self):
        """
        获取本次对话上传的文件, 用于透传给被当作工具调用的应用/MCP
        """
        chat_files = {}
        for field in CHAT_FILE_LIST_FIELDS:
            file_list = getattr(self.workflow_manage, field, None) or []
            items = [
                {key: item.get(key) for key in ("name", "url", "file_id") if item.get(key) is not None}
                for item in file_list
                if isinstance(item, dict)
            ]
            if items:
                chat_files[field] = items
        return chat_files

    def get_form_data(self):
        """
        获取当前会话的用户输入参数，用于透传给作为工具调用的子智能体。

        循环工作流会创建独立的 WorkflowManage，并将自身的 form_data 初始化为
        空字典，因此需要继续从父工作流中查找原始用户输入。
        """
        workflow_manage = self.workflow_manage
        visited = set()
        while workflow_manage is not None and id(workflow_manage) not in visited:
            visited.add(id(workflow_manage))
            form_data = getattr(workflow_manage, "form_data", None)
            if isinstance(form_data, dict) and form_data:
                return form_data.copy()
            workflow_manage = getattr(workflow_manage, "parentWorkflowManage", None)
        return {}

    def handle_variables(self, tool_params):
        # 处理参数中的变量
        for k, v in tool_params.items():
            if type(v) == str:
                tool_params[k] = self.workflow_manage.generate_prompt(tool_params[k])
            elif type(v) == dict:
                self.handle_variables(v)
            elif (type(v) == list) and len(v) > 0 and (type(v[0]) == str):
                tool_params[k] = self.get_reference_content(v)
        return tool_params

    def get_reference_content(self, fields: List[str]):
        return str(self.workflow_manage.get_reference_field(fields[0], fields[1:])) if fields else ""

    @staticmethod
    def prepare_dialogue_history(records, number, dialogue_type, runtime_id, context, question, enabled):
        if not enabled or dialogue_type != "NODE":
            return BaseChatNode.get_history_message(records, number, dialogue_type, runtime_id), {
                "enabled": enabled, "removed_contexts": 0, "removed_chars": 0, "status": "preserved"}
        turns = []
        for record in (records[-number:] if number > 0 else []):
            details = record.get_node_details_runtime_node_id(runtime_id)
            if details is not None:
                turns.append({"question": details.get("question"), "answer": details.get("answer"),
                              "raw_question": details.get("raw_question"),
                              "context": details.get("dialogue_context")})
        turns, trace = prepare_history(turns, context, question, enabled)
        messages = []
        for turn in turns:
            for cls, field in ((HumanMessage, "question"), (AIMessage, "answer")):
                content = turn[field]
                if isinstance(content, str):
                    content = re.sub(r"<form_rander>.*?</form_rander>", "", content, flags=re.DOTALL)
                messages.append(cls(content))
        return messages, trace

    @staticmethod
    def get_history_message(history_chat_record, dialogue_number, dialogue_type, runtime_node_id):
        start_index = len(history_chat_record) - dialogue_number
        history_message = reduce(
            lambda x, y: [*x, *y],
            [
                get_message(history_chat_record[index], dialogue_type, runtime_node_id)
                for index in range(start_index if start_index > 0 else 0, len(history_chat_record))
            ],
            [],
        )
        for message in history_message:
            if isinstance(message.content, str):
                message.content = re.sub(r"<form_rander>.*?<\/form_rander>", "", message.content, flags=re.DOTALL)
        return history_message

    def generate_prompt_question(self, prompt, model):
        image = self.get_image()
        video = self.get_video()
        vision = self.is_vision()
        videos = []
        images = []
        if image and vision:
            images = self._process_images(image)
        if video and vision:
            videos = self._process_videos(video, model)
        prompt = self.workflow_manage.generate_prompt(prompt)
        if images or videos:
            return HumanMessage(content=[*videos, *images, {"type": "text", "text": prompt}])
        return HumanMessage(content=prompt)

    def is_vision(self):
        if "vision" in self.node_params_serializer.data:
            return self.node_params_serializer.data.get("vision")
        return False

    def get_image(self):
        if "image_list" in self.node_params_serializer.data:
            image = self.workflow_manage.get_reference_field(
                self.node_params_serializer.data.get("image_list")[0],
                self.node_params_serializer.data.get("image_list")[1:],
            )
            return image
        return None

    def get_video(self):
        if "video_list" in self.node_params_serializer.data:
            video = self.workflow_manage.get_reference_field(
                self.node_params_serializer.data.get("video_list")[0],
                self.node_params_serializer.data.get("video_list")[1:],
            )
            return video
        return None

    def _process_videos(self, image, video_model):
        videos = []
        if isinstance(image, str) and image.startswith("http"):
            videos.append({"type": "video_url", "video_url": {"url": image}})
        elif image is not None and len(image) > 0:
            for img in image:
                if "file_id" in img:
                    file_id = img["file_id"]
                    file = QuerySet(File).filter(id=file_id).first()
                    url = video_model.upload_file_and_get_url(file.get_bytes(), file.file_name)
                    videos.append({"type": "video_url", "video_url": {"url": url}})
                elif "url" in img and img["url"].startswith("http"):
                    videos.append({"type": "video_url", "video_url": {"url": img["url"]}})
        return videos

    def _process_images(self, image):
        """
        处理图像数据，转换为模型可识别的格式
        """
        images = []
        if isinstance(image, str) and image.startswith("http"):
            images.append({"type": "image_url", "image_url": {"url": image}})
        elif image is not None and len(image) > 0:
            for img in image:
                if "file_id" in img:
                    file_id = img["file_id"]
                    file = QuerySet(File).filter(id=file_id).first()
                    image_bytes = file.get_bytes()
                    base64_image = base64.b64encode(image_bytes).decode("utf-8")
                    image_format = what(None, image_bytes)
                    images.append(
                        {"type": "image_url", "image_url": {"url": f"data:image/{image_format};base64,{base64_image}"}}
                    )
                elif "url" in img and img["url"].startswith("http"):
                    images.append({"type": "image_url", "image_url": {"url": img["url"]}})
        return images

    def generate_message_list(self, question, history_message):
        return [*history_message, question]

    @staticmethod
    def reset_message_list(message_list: List[BaseMessage], answer_text):
        result = [
            {"role": "user" if isinstance(message, HumanMessage) else "ai", "content": message.content}
            for message in message_list
        ]
        result.append({"role": "ai", "content": answer_text})
        return result

    def get_details(self, index: int, **kwargs):
        return {
            "name": self.node.properties.get("stepName"),
            "index": index,
            "run_time": self.context.get("run_time"),
            "system": self.context.get("system"),
            "history_message": self.context.get("history_message"),
            "raw_question": self.context.get("raw_question"),
            "dialogue_context": self.context.get("dialogue_context"),
            "dialogue_policy": self.context.get("dialogue_policy"),
            "question": self.context.get("question"),
            "answer": self.context.get("answer"),
            "reasoning_content": self.context.get("reasoning_content"),
            "enableException": self.node.properties.get("enableException"),
            "type": self.node.type,
            "message_tokens": self.context.get("message_tokens"),
            "answer_tokens": self.context.get("answer_tokens"),
            "status": self.status,
            "err_message": self.err_message,
        }
