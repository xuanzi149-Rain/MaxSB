# coding=utf-8
"""Deterministic retrieval budgets. Unknown questions preserve the fixed configuration."""
import re
import unicodedata


DEFAULT_PROFILES = {
    'none': {'retrieve': False, 'top_n': 1, 'rerank': False},
    'simple': {'retrieve': True, 'top_n': 3, 'rerank': False},
    'complex': {'retrieve': True, 'top_n': 8, 'rerank': True},
}
GREETINGS = {'你好', '您好', '嗨', '哈喽', '谢谢', '多谢', '再见', 'hello', 'hi', 'thanks', 'thank you', 'bye'}
COMPARISON = re.compile(r'比较|对比|区别|差异|优缺点|同时|并且|而且|以及|且|分别|compare|difference|versus|\bvs\b',
                        re.I)
FACT = re.compile(r'多少|几[天本人次个元岁]|多久|何时|哪里|哪年|是谁|是什么|是否|能否|可以.{0,12}吗|'
                  r'\b(?:what is|who is|when|where|how many|how much|how long)\b', re.I)
FOLLOWUP = re.compile(r'^(?:它|他们|她|他|这个|那个|这项|那项|前者|后者|第二个|那第二个|it\b|that\b|this\b)', re.I)


def classify_question(question):
    text = unicodedata.normalize('NFKC', question).strip().lower()
    if text.strip(' !?。，,.；;') in GREETINGS:
        return 'none', 'exact_greeting'
    if not text or FOLLOWUP.search(text):
        return 'unknown', 'ambiguous_or_followup'
    if COMPARISON.search(text) or len(FACT.findall(text)) > 1 or len(re.findall(r'[?？]', text)) > 1:
        return 'complex', 'comparison_or_multiple_conditions'
    # A single bounded fact question; long or compound requests conservatively fall back.
    if len(text) <= 100 and FACT.search(text) and not re.search(r'[;；]|\band\b|和|与', text):
        return 'simple', 'single_fact'
    return 'unknown', 'no_explicit_rule'


def decide_retrieval(question, settings):
    policy = settings.get('retrieval_policy') or {}
    if not policy.get('enabled', False):
        return None
    category, reason = classify_question(question)
    profile = {'retrieve': True, 'top_n': settings['top_n'], 'rerank': None}
    if category in DEFAULT_PROFILES:
        profile = {**DEFAULT_PROFILES[category], **policy.get(category, {})}
    if not profile['retrieve']:
        profile = {**profile, 'top_n': 0, 'rerank': False}
    return {'version': 1, 'question': question, 'category': category, 'reason': reason, **profile,
            'similarity': settings['similarity'], 'search_mode': settings['search_mode']}
